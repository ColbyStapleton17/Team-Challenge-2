"""NovaRetail Customer Intelligence Dashboard.

Streamlit app that turns NR_dataset.xlsx into an executive dashboard with
sidebar filters, independently calculated risk indicators, data-driven
recommendations and an optional AI chatbot (OpenAI) grounded in the
currently filtered data.

Run locally:  streamlit run app.py
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------
DATA_PATH = Path(__file__).parent / "NR_dataset.xlsx"  # relative -> works on Streamlit Cloud
REQUIRED_COLS = [
    "label", "CustomerID", "TransactionID", "TransactionDate", "ProductCategory",
    "PurchaseAmount", "CustomerAgeGroup", "CustomerGender", "CustomerRegion",
    "CustomerSatisfaction", "RetailChannel",
]
SEGMENTS = ["Promising", "Growth", "Stable", "Decline"]
SEGMENT_ORDER = SEGMENTS + ["Unlabeled"]
SEGMENT_COLORS = {
    "Promising": "#4C78A8", "Growth": "#54A24B", "Stable": "#9AA0A6",
    "Decline": "#E4572E", "Unlabeled": "#D0D0D0",
}
AGE_ORDER = ["18-24", "25-34", "35-44", "45-54", "55+"]

# The raw file contains 35 spellings of what are really ~10 categories.
# This mapping is a documented analyst decision (see README / Data Quality tab).
CATEGORY_MAP = {
    "Electronics": "Electronics", "Gaming": "Electronics",
    "Clothing": "Clothing & Fashion", "Fashion": "Clothing & Fashion",
    "Fashion & Apparel": "Clothing & Fashion", "Fashion Accessories": "Clothing & Fashion",
    "Sportswear": "Clothing & Fashion", "Children's Clothing": "Clothing & Fashion",
    "Groceries": "Groceries & Food", "Grocery": "Groceries & Food",
    "Grocery Items": "Groceries & Food", "Food & Beverages": "Groceries & Food",
    "Books": "Books", "Books & Magazines": "Books",
    "Home Appliances": "Home & Furniture", "Home Decor": "Home & Furniture",
    "Home & Garden": "Home & Furniture", "Home Improvement": "Home & Furniture",
    "Furniture": "Home & Furniture", "Furniture & Decor": "Home & Furniture",
    "Gardening Tools": "Home & Furniture",
    "Beauty Products": "Health & Beauty", "Beauty & Personal Care": "Health & Beauty",
    "Cosmetics": "Health & Beauty", "Health & Beauty": "Health & Beauty",
    "Health & Wellness": "Health & Beauty", "Health Supplements": "Health & Beauty",
    "Sporting Goods": "Sports & Outdoors", "Sports & Outdoors": "Sports & Outdoors",
    "Sports Equipment": "Sports & Outdoors", "Outdoor Equipment": "Sports & Outdoors",
    "Toys": "Toys & Games", "Toys & Games": "Toys & Games",
    "Office Supplies": "Other", "Automotive": "Other",
}

LOW_SAT_THRESHOLD = 2.5   # customer average satisfaction at/below this is a warning sign
SPEND_DROP_RATIO = 0.5    # recent spend below 50% of prior-period spend is a warning sign


def money(x: float, decimals: int = 0) -> str:
    """Format a number as US currency; tolerate NaN."""
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "n/a"
    return f"-${abs(x):,.{decimals}f}" if x < 0 else f"${x:,.{decimals}f}"


# --------------------------------------------------------------------------
# Stage 1: load, validate and clean
# --------------------------------------------------------------------------
@st.cache_data(show_spinner="Loading dataset...")
def load_raw(path: str, mtime: float) -> tuple[pd.DataFrame, list[str]]:
    """Read the Excel file. `mtime` is only a cache key so edits invalidate the cache."""
    xl = pd.ExcelFile(path, engine="openpyxl")
    sheet = "data" if "data" in xl.sheet_names else xl.sheet_names[0]
    return xl.parse(sheet), xl.sheet_names


@st.cache_data(show_spinner=False)
def clean_data(raw: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Validate and standardise the raw table; return (clean_df, audit_dict).

    Nothing is deleted because it "looks" like a duplicate. Only rows with an
    unparseable date or a missing/non-positive amount are excluded (counted in audit).
    """
    missing = [c for c in REQUIRED_COLS if c not in raw.columns]
    if missing:
        raise ValueError(f"Dataset is missing expected columns: {', '.join(missing)}")

    d = raw.copy()
    audit: dict = {
        "rows_raw": len(d),
        "columns": list(raw.columns),
        "missing_by_column": raw.isna().sum().to_dict(),
        "decisions": [],
    }

    for c in ["label", "CustomerID", "TransactionID", "ProductCategory", "CustomerAgeGroup",
              "CustomerGender", "CustomerRegion", "RetailChannel"]:
        d[c] = d[c].astype("string").str.strip()

    d["Date"] = pd.to_datetime(d["TransactionDate"], errors="coerce")
    d["Amount"] = pd.to_numeric(d["PurchaseAmount"], errors="coerce")
    d["Satisfaction"] = pd.to_numeric(d["CustomerSatisfaction"], errors="coerce")

    bad_sat = (d["Satisfaction"].notna()) & ~d["Satisfaction"].between(1, 5)
    audit["invalid_satisfaction"] = int(bad_sat.sum())
    d.loc[bad_sat, "Satisfaction"] = np.nan

    invalid = d["Date"].isna() | d["Amount"].isna() | (d["Amount"] <= 0) | d["CustomerID"].isna()
    audit["rows_excluded_invalid"] = int(invalid.sum())
    d = d[~invalid].copy()

    # Behavioural segment: keep the supplied label; blanks/unknown -> "Unlabeled".
    seg = d["label"].str.title()
    audit["unlabeled_rows"] = int((~seg.isin(SEGMENTS)).sum())
    d["Segment"] = seg.where(seg.isin(SEGMENTS), "Unlabeled").astype(str)

    # Category standardisation
    d["RawCategory"] = d["ProductCategory"].astype(str)
    d["Category"] = d["RawCategory"].map(CATEGORY_MAP).fillna("Other")
    audit["raw_categories"] = int(d["RawCategory"].nunique())
    audit["clean_categories"] = int(d["Category"].nunique())

    # Age group: "55-64" and "55+" are merged because "55+" has only 2 rows
    d["AgeGroup"] = d["CustomerAgeGroup"].replace({"55-64": "55+"})
    audit["age_harmonised_rows"] = int((d["CustomerAgeGroup"] == "55-64").sum())

    d["Gender"] = d["CustomerGender"]
    d["Region"] = d["CustomerRegion"]
    d["Channel"] = d["RetailChannel"]
    d["RecordID"] = raw.loc[d.index, "idx"] if "idx" in raw.columns else d.index
    d["Date"] = d["Date"].dt.normalize()

    # --- Flags (rows are retained; flags are informational) ---
    tx_cust = d.groupby("TransactionID")["CustomerID"].transform("nunique")
    d["SharedTransactionID"] = tx_cust > 1
    d["PossibleDuplicate"] = d.duplicated(["CustomerID", "Date", "Amount", "Category"], keep=False)

    cust_attr = d.groupby("CustomerID").agg(
        segs=("Segment", "nunique"), regions=("Region", "nunique"),
        ages=("AgeGroup", "nunique"), genders=("Gender", "nunique"),
    )
    audit.update({
        "unique_customers": int(d["CustomerID"].nunique()),
        "unique_transaction_ids": int(d["TransactionID"].nunique()),
        "rows_with_repeated_txid": int(d["TransactionID"].duplicated(keep=False).sum()),
        "txids_shared_by_multiple_customers": int((d.groupby("TransactionID")["CustomerID"].nunique() > 1).sum()),
        "possible_duplicate_rows": int(d["PossibleDuplicate"].sum()),
        "customers_multi_segment": int((cust_attr["segs"] > 1).sum()),
        "customers_multi_region": int((cust_attr["regions"] > 1).sum()),
        "customers_multi_age": int((cust_attr["ages"] > 1).sum()),
        "customers_multi_gender": int((cust_attr["genders"] > 1).sum()),
        "customers_single_record": int((d.groupby("CustomerID").size() == 1).sum()),
        "date_min": d["Date"].min(), "date_max": d["Date"].max(),
        "span_days": int((d["Date"].max() - d["Date"].min()).days + 1),
        "rows_clean": len(d),
        "amount_min": float(d["Amount"].min()), "amount_max": float(d["Amount"].max()),
    })
    audit["decisions"] = [
        "Each row is treated as one purchase record (line item); 'Transactions' = record count.",
        f"TransactionID is NOT unique ({audit['unique_transaction_ids']} distinct IDs over {len(d)} rows), so it is "
        "treated as a basket/order reference and never used as a record key.",
        f"Customers are counted with nunique(CustomerID) = {audit['unique_customers']}, not row counts "
        "(the brief mentions 99 customers; the file contains 100 rows).",
        "Segment labels are used exactly as supplied on each row. A customer can carry several labels over time, "
        "so per-segment customer counts overlap and do not sum to the total.",
        f"{audit['unlabeled_rows']} row(s) with a blank label are kept as 'Unlabeled'.",
        f"{audit['raw_categories']} category spellings were consolidated into {audit['clean_categories']} groups (CATEGORY_MAP).",
        "Age group '55-64' merged into '55+'.",
        f"{audit['possible_duplicate_rows']} rows share customer+date+amount+category: flagged, not removed.",
        f"{audit['txids_shared_by_multiple_customers']} TransactionID(s) are shared by more than one CustomerID: flagged, not removed.",
        "Customer demographics (region, age group) vary between rows of the same customer; "
        "filters therefore act on record-level values.",
    ]
    return d.reset_index(drop=True), audit


# --------------------------------------------------------------------------
# Filters
# --------------------------------------------------------------------------
def filter_defaults(df: pd.DataFrame) -> dict:
    ages = [a for a in AGE_ORDER if a in set(df["AgeGroup"])] + sorted(set(df["AgeGroup"]) - set(AGE_ORDER))
    return {
        "f_date": (df["Date"].min().date(), df["Date"].max().date()),
        "f_seg": [s for s in SEGMENT_ORDER if s in set(df["Segment"])],
        "f_cat": sorted(df["Category"].unique()),
        "f_reg": sorted(df["Region"].unique()),
        "f_chan": sorted(df["Channel"].unique()),
        "f_age": ages,
        "f_gen": sorted(df["Gender"].unique()),
        "f_window": 14,
    }


def reset_filters(defaults: dict) -> None:
    for k, v in defaults.items():
        st.session_state[k] = v


def sidebar_filters(df: pd.DataFrame) -> tuple[dict, int]:
    defaults = filter_defaults(df)
    for k, v in defaults.items():
        st.session_state.setdefault(k, v)

    st.sidebar.header("Filters")
    st.sidebar.button("Reset filters", on_click=reset_filters, args=(defaults,), use_container_width=True)
    st.sidebar.date_input("Transaction date range", key="f_date",
                          min_value=defaults["f_date"][0], max_value=defaults["f_date"][1],
                          help="Inclusive range. Data covers a short window, so trends are indicative only.")
    st.sidebar.multiselect("Behavioral segment", defaults["f_seg"], key="f_seg",
                           help="Existing label on each record, used as supplied.")
    st.sidebar.multiselect("Product category", defaults["f_cat"], key="f_cat",
                           help="Standardised categories (35 raw spellings consolidated).")
    st.sidebar.multiselect("Customer region", defaults["f_reg"], key="f_reg")
    st.sidebar.multiselect("Retail channel", defaults["f_chan"], key="f_chan")
    st.sidebar.multiselect("Customer age group", defaults["f_age"], key="f_age")
    st.sidebar.multiselect("Customer gender", defaults["f_gen"], key="f_gen")

    st.sidebar.header("Analysis settings")
    st.sidebar.slider("Recent window (days)", 7, 21, key="f_window",
                      help="Recent = last N days of the filtered data; Prior = the N days before that. "
                           "Used for growth and risk indicators.")

    sel = {k: st.session_state[k] for k in defaults if k != "f_window"}
    return sel, int(st.session_state["f_window"])


def apply_filters(df: pd.DataFrame, sel: dict) -> pd.DataFrame:
    d = sel["f_date"]
    if isinstance(d, (tuple, list)) and len(d) == 2:
        start, end = pd.Timestamp(d[0]), pd.Timestamp(d[1])
    else:  # user is mid-selection (only one date picked): keep full range
        start, end = df["Date"].min(), df["Date"].max()
    m = (
        df["Date"].between(start, end)
        & df["Segment"].isin(sel["f_seg"])
        & df["Category"].isin(sel["f_cat"])
        & df["Region"].isin(sel["f_reg"])
        & df["Channel"].isin(sel["f_chan"])
        & df["AgeGroup"].isin(sel["f_age"])
        & df["Gender"].isin(sel["f_gen"])
    )
    return df[m]


def describe_filters(df: pd.DataFrame, dff: pd.DataFrame, sel: dict, window: int) -> str:
    """Human-readable filter context, also passed to the chatbot."""
    defaults = filter_defaults(df)
    parts = [f"Dates {dff['Date'].min():%Y-%m-%d} to {dff['Date'].max():%Y-%m-%d}"]
    names = {"f_seg": "Segment", "f_cat": "Category", "f_reg": "Region", "f_chan": "Channel",
             "f_age": "Age group", "f_gen": "Gender"}
    for k, label in names.items():
        if set(sel[k]) != set(defaults[k]):
            parts.append(f"{label}: {', '.join(sel[k])}")
    parts.append(f"Recent window: {window} days")
    return " | ".join(parts)


# --------------------------------------------------------------------------
# Stage 2: metrics
# --------------------------------------------------------------------------
def compute_kpis(d: pd.DataFrame) -> dict:
    """Revenue, unique customers (nunique, not rows), record count, avg value, avg satisfaction."""
    rev = float(d["Amount"].sum())
    n_tx = len(d)
    return {
        "revenue": rev,
        "customers": int(d["CustomerID"].nunique()),
        "transactions": n_tx,
        "distinct_txids": int(d["TransactionID"].nunique()),
        "avg_tx": rev / n_tx if n_tx else float("nan"),
        "avg_sat": float(d["Satisfaction"].mean()) if d["Satisfaction"].notna().any() else float("nan"),
        "sat_n": int(d["Satisfaction"].notna().sum()),
    }


def segment_summary(d: pd.DataFrame) -> pd.DataFrame:
    g = d.groupby("Segment").agg(
        Revenue=("Amount", "sum"), Customers=("CustomerID", "nunique"),
        Transactions=("Amount", "size"), AvgSatisfaction=("Satisfaction", "mean"),
    )
    g["RevenueShare"] = g["Revenue"] / g["Revenue"].sum()
    g["TxPerCustomer"] = g["Transactions"] / g["Customers"]      # frequency within segment
    g["AvgTransaction"] = g["Revenue"] / g["Transactions"]
    g = g.reindex([s for s in SEGMENT_ORDER if s in g.index]).reset_index()
    return g


def customer_summary(d: pd.DataFrame, window: int) -> tuple[pd.DataFrame, dict]:
    """One row per CustomerID with historical value, recent change and independent risk indicators.

    Recent window  = last `window` days of the filtered data.
    Prior window   = the `window` days immediately before it.
    Window is shrunk automatically if the observation period is too short.
    """
    span = int((d["Date"].max() - d["Date"].min()).days + 1)
    w = max(1, min(window, span // 2)) if span >= 2 else 1
    end = d["Date"].max()
    recent_start = end - pd.Timedelta(days=w)          # recent: Date > recent_start
    prior_start = end - pd.Timedelta(days=2 * w)       # prior:  prior_start < Date <= recent_start
    meta = {"end": end, "window": w, "span_days": span,
            "recent_range": (recent_start + pd.Timedelta(days=1), end),
            "prior_range": (prior_start + pd.Timedelta(days=1), recent_start),
            "window_adjusted": w != window}

    s = d.sort_values(["Date", "RecordID"])
    cust = s.groupby("CustomerID").agg(
        Revenue=("Amount", "sum"), Transactions=("Amount", "size"),
        FirstPurchase=("Date", "min"), LastPurchase=("Date", "max"),
        AvgSatisfaction=("Satisfaction", "mean"),
        LatestSegment=("Segment", "last"), SegmentsSeen=("Segment", "nunique"),
        DeclineRecords=("Segment", lambda x: int((x == "Decline").sum())),
    )
    recent_m = s["Date"] > recent_start
    prior_m = (s["Date"] > prior_start) & ~recent_m
    cust["RecentRevenue"] = s[recent_m].groupby("CustomerID")["Amount"].sum().reindex(cust.index).fillna(0.0)
    cust["PriorRevenue"] = s[prior_m].groupby("CustomerID")["Amount"].sum().reindex(cust.index).fillna(0.0)
    cust["RevenueChange"] = cust["RecentRevenue"] - cust["PriorRevenue"]
    cust["DaysSinceLast"] = (end - cust["LastPurchase"]).dt.days

    # Independent risk indicators (do NOT use the supplied segment label)
    cust["Inactive"] = cust["LastPurchase"] <= recent_start
    cust["SpendDrop"] = (cust["PriorRevenue"] > 0) & (cust["RecentRevenue"] > 0) & \
                        (cust["RecentRevenue"] < SPEND_DROP_RATIO * cust["PriorRevenue"])
    cust["LowSatisfaction"] = cust["AvgSatisfaction"] <= LOW_SAT_THRESHOLD
    cust["RiskFlags"] = cust[["Inactive", "SpendDrop", "LowSatisfaction"]].sum(axis=1).astype(int)
    cust["RiskLevel"] = pd.cut(cust["RiskFlags"], [-1, 0, 1, 3], labels=["Low", "Watch", "Elevated"]).astype(str)
    cust["RecentGrowth"] = (cust["RecentRevenue"] > cust["PriorRevenue"]) & (cust["RecentRevenue"] > 0)
    cust = cust.reset_index()
    cust["CustomerID"] = cust["CustomerID"].astype(str)
    return cust, meta


def segment_recent_vs_prior(d: pd.DataFrame, meta: dict) -> pd.DataFrame:
    r0, r1 = meta["recent_range"]
    p0, p1 = meta["prior_range"]
    rec = d[d["Date"].between(r0, r1)].groupby("Segment")["Amount"].sum()
    pri = d[d["Date"].between(p0, p1)].groupby("Segment")["Amount"].sum()
    out = pd.DataFrame({"Prior": pri, "Recent": rec}).fillna(0.0)
    out = out.reindex([s for s in SEGMENT_ORDER if s in out.index]).reset_index().rename(columns={"index": "Segment"})
    return out


def dim_summary(d: pd.DataFrame, col: str) -> pd.DataFrame:
    g = d.groupby(col).agg(Revenue=("Amount", "sum"), Transactions=("Amount", "size"),
                           Customers=("CustomerID", "nunique"))
    g["AvgTransaction"] = g["Revenue"] / g["Transactions"]
    g["RevenueShare"] = g["Revenue"] / g["Revenue"].sum()
    return g.sort_values("Revenue", ascending=False).reset_index()


def safe_corr(a: pd.Series, b: pd.Series) -> tuple[float, int]:
    """Spearman correlation with n; NaN if not computable."""
    x = pd.concat([a, b], axis=1).dropna()
    if len(x) < 5 or x.iloc[:, 0].nunique() < 2 or x.iloc[:, 1].nunique() < 2:
        return float("nan"), len(x)
    return float(x.corr(method="spearman").iloc[0, 1]), len(x)


# --------------------------------------------------------------------------
# Recommendations (computed from the filtered data; observed vs hypothesis)
# --------------------------------------------------------------------------
def build_recommendations(d: pd.DataFrame, cust: pd.DataFrame, meta: dict) -> list[dict]:
    recs: list[dict] = []
    total = d["Amount"].sum()
    if total <= 0:
        return recs

    # 1. Revenue concentration
    top = cust.nlargest(5, "Revenue")
    share = top["Revenue"].sum() / total
    recs.append({
        "title": "Protect and grow the highest-revenue customers",
        "observed": f"The top {len(top)} of {len(cust)} customers generate {share:.0%} of revenue "
                    f"({money(top['Revenue'].sum())} of {money(total)}).",
        "hypothesis": "Revenue is concentrated in a few accounts, so losing one would be material. "
                      "The data cannot show why they buy more.",
        "target": "Top-5 customers by historical revenue (see Segmentation tab).",
        "action": "Assign relationship owners, offer early access/loyalty benefits, and monitor their recent activity weekly.",
        "metric": "Top-customer revenue retention and repeat-purchase rate over the next quarter.",
    })

    # 2. Retention for Decline-labelled customers with independent warning signs
    dec = cust[cust["DeclineRecords"] > 0]
    if len(dec):
        elev = dec[dec["RiskFlags"] >= 2]
        sd = d[d["Segment"] == "Decline"]["Satisfaction"].mean()
        so = d[d["Segment"] != "Decline"]["Satisfaction"].mean()
        recs.append({
            "title": "Run a targeted win-back and service-recovery campaign",
            "observed": f"{len(dec)} customers carry at least one 'Decline' record; {len(elev)} of them also show "
                        f"2+ independent warning signs (inactive, spend drop, low satisfaction). "
                        f"Revenue linked to those {len(elev)} customers: {money(elev['Revenue'].sum())}. "
                        f"Average satisfaction on Decline records is {sd:.2f} vs {so:.2f} on other records."
                        if not np.isnan(sd) and not np.isnan(so) else
                        f"{len(dec)} customers carry at least one 'Decline' record; {len(elev)} show 2+ warning signs.",
            "hypothesis": "Low satisfaction may be contributing to reduced engagement. This is an association, not proof of churn.",
            "target": "Customers with Decline records and Elevated risk (Risk & Retention tab).",
            "action": "Personal outreach on service issues, a time-limited incentive on their previously purchased categories, and a satisfaction follow-up.",
            "metric": "Repurchase rate within 30 days of contact; change in average satisfaction; reactivated customers.",
        })

    # 3. Category / channel investment
    cat = dim_summary(d, "Category")
    chan = dim_summary(d, "Channel")
    if len(cat):
        c0 = cat.iloc[0]
        txt = f"{c0['Category']} is the largest category: {money(c0['Revenue'])} ({c0['RevenueShare']:.0%} of revenue)."
        if len(chan) > 1:
            hi, lo = chan.sort_values("AvgTransaction", ascending=False).iloc[[0, -1]].to_dict("records")
            txt += (f" {hi['Channel']} averages {money(hi['AvgTransaction'], 2)} per transaction vs "
                    f"{money(lo['AvgTransaction'], 2)} in {lo['Channel']}.")
        recs.append({
            "title": "Prioritise inventory and promotion in the leading categories; test channel parity",
            "observed": txt,
            "hypothesis": "Higher ticket size in one channel may reflect product mix rather than channel quality; margin data is not available.",
            "target": f"{c0['Category']} and the lower-ticket channel.",
            "action": "Focus promotions and stock availability on top categories; A/B test cross-sell bundles in the lower-ticket channel.",
            "metric": "Revenue per category, average transaction value by channel, bundle attach rate.",
        })

    # 4. Regional opportunity (recent vs prior)
    r0, r1 = meta["recent_range"]
    p0, p1 = meta["prior_range"]
    reg_recent = d[d["Date"].between(r0, r1)].groupby("Region")["Amount"].sum()
    reg_prior = d[d["Date"].between(p0, p1)].groupby("Region")["Amount"].sum()
    reg = pd.DataFrame({"Prior": reg_prior, "Recent": reg_recent}).fillna(0.0)
    reg["Change"] = reg["Recent"] - reg["Prior"]
    if len(reg) > 1 and reg["Prior"].sum() > 0:
        best, worst = reg["Change"].idxmax(), reg["Change"].idxmin()
        all_down = bool((reg["Change"] < 0).all())
        lead = ("Revenue fell in every region; " if all_down else "") + \
               f"{best} changed {money(reg.loc[best, 'Change'])} ({'smallest decline' if all_down else 'strongest growth'}) and " \
               f"{worst} changed {money(reg.loc[worst, 'Change'])}"
        recs.append({
            "title": "Direct regional marketing toward momentum and test fixes where revenue is slipping",
            "observed": f"{lead}, comparing the recent {meta['window']} days with the prior {meta['window']} days.",
            "hypothesis": "With only ~5 weeks of data, regional swings may be noise or timing, not durable trends.",
            "target": f"{best} (scale) and {worst} (diagnose).",
            "action": "Run small regional pilots (offers, local media) and re-measure over a longer window before shifting budget.",
            "metric": "Regional revenue growth vs prior period; new-customer count per region.",
        })

    # 5. Promising customers with a single purchase
    prom = cust[(cust["LatestSegment"] == "Promising")]
    one = prom[prom["Transactions"] == 1]
    if len(prom):
        recs.append({
            "title": "Convert 'Promising' customers into repeat buyers",
            "observed": f"{len(one)} of {len(prom)} customers whose latest label is Promising have only one purchase record.",
            "hypothesis": "A timely second-purchase incentive could increase repeat rate; not testable with current data.",
            "target": "Promising customers with a single purchase.",
            "action": "Onboarding sequence with a second-purchase offer and category recommendations within 14 days.",
            "metric": "Second-purchase rate within 30 days; segment migration Promising -> Growth.",
        })
    return recs


# --------------------------------------------------------------------------
# Stage 4: chatbot
# --------------------------------------------------------------------------
SYSTEM_PROMPT = """You are the NovaRetail Customer Intelligence assistant for Sophia Martinez, Director of Customer Intelligence.
Rules:
- Answer ONLY from the JSON data context provided. Never invent numbers. If the context lacks the evidence, say so and name the data that would be needed.
- Always state the filter context (dates, segment, category, region, channel, etc.) that your numbers refer to.
- Clearly label statements as: Observed (from the data), Hypothesis (plausible but unproven), or Recommendation (suggested action).
- Segment labels are existing classifications; do not claim they were model-generated or that they prove causation or future churn.
- Note that the observation window is short (about five weeks) when discussing trends or growth.
- Customer IDs are pseudonymous; mention at most a few when truly useful. Do not speculate about individuals' identities.
- Be concise. Format currency as USD."""


def get_api_key() -> str | None:
    """Read OPENAI_API_KEY from Streamlit secrets or the environment (never hard-coded)."""
    try:
        key = st.secrets["OPENAI_API_KEY"]
        if key:
            return str(key)
    except Exception:  # no secrets file / key not set
        pass
    return os.environ.get("OPENAI_API_KEY") or None


def get_model_name() -> str:
    try:
        return str(st.secrets["OPENAI_MODEL"])
    except Exception:
        return os.environ.get("OPENAI_MODEL", "gpt-4o-mini")


def build_chat_context(d: pd.DataFrame, cust: pd.DataFrame, meta: dict, filter_desc: str) -> dict:
    """Pre-computed aggregates for the filtered data. The LLM only reads these numbers."""
    k = compute_kpis(d)
    r = lambda df_, n=2: json.loads(df_.round(n).to_json(orient="records", date_format="iso"))  # noqa: E731
    seg_rp = segment_recent_vs_prior(d, meta)
    reg_r = d[d["Date"].between(*meta["recent_range"])].groupby("Region")["Amount"].sum()
    reg_p = d[d["Date"].between(*meta["prior_range"])].groupby("Region")["Amount"].sum()
    reg_rp = pd.DataFrame({"PriorRevenue": reg_p, "RecentRevenue": reg_r}).fillna(0.0).reset_index()
    weekly = d.groupby(pd.Grouper(key="Date", freq="W-SUN"))["Amount"].sum().reset_index()
    weekly["Date"] = weekly["Date"].dt.strftime("%Y-%m-%d")
    dec = cust[cust["DeclineRecords"] > 0].sort_values("RiskFlags", ascending=False).head(10)
    ctx = {
        "filter_context": filter_desc,
        "notes": [
            "Rows are purchase records; 'transactions' = record count. TransactionID repeats across rows.",
            "Segment labels are per record; a customer can appear in several segments, so segment customer counts overlap.",
            f"Observation window is {meta['span_days']} days. Recent window={meta['window']} days "
            f"({meta['recent_range'][0]:%Y-%m-%d} to {meta['recent_range'][1]:%Y-%m-%d}); prior window "
            f"({meta['prior_range'][0]:%Y-%m-%d} to {meta['prior_range'][1]:%Y-%m-%d}).",
            "Risk indicators (Inactive, SpendDrop, LowSatisfaction<=2.5) are calculated independently of the segment label.",
        ],
        "kpis": {kk: (None if isinstance(v, float) and np.isnan(v) else round(v, 2)) for kk, v in k.items()},
        "by_segment": r(segment_summary(d)),
        "by_category": r(dim_summary(d, "Category")),
        "by_region": r(dim_summary(d, "Region")),
        "by_channel": r(dim_summary(d, "Channel")),
        "by_age_group": r(dim_summary(d, "AgeGroup")),
        "by_gender": r(dim_summary(d, "Gender")),
        "weekly_revenue": r(weekly),
        "segment_recent_vs_prior": r(seg_rp),
        "region_recent_vs_prior": r(reg_rp),
        "top_customers_by_revenue": r(cust.nlargest(10, "Revenue")[["CustomerID", "Revenue", "Transactions", "LatestSegment", "AvgSatisfaction"]]),
        "risk_summary": {
            "customers_by_risk_level": cust["RiskLevel"].value_counts().to_dict(),
            "customers_with_decline_records": int((cust["DeclineRecords"] > 0).sum()),
            "decline_customers_elevated_risk": int(((cust["DeclineRecords"] > 0) & (cust["RiskFlags"] >= 2)).sum()),
        },
        "decline_customers_top10_by_flags": r(dec[["CustomerID", "Revenue", "Transactions", "DaysSinceLast", "AvgSatisfaction", "RiskFlags"]]),
    }
    return ctx


def ask_llm(question: str, history: list[dict], context: dict, api_key: str) -> tuple[str | None, str | None]:
    """Return (answer, error_message). Errors never raise into the UI."""
    try:
        from openai import OpenAI
    except ImportError:
        return None, "The `openai` package is not installed. Add it to requirements.txt and reinstall."
    try:
        client = OpenAI(api_key=api_key, timeout=60)
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "system", "content": "DATA CONTEXT (JSON):\n" + json.dumps(context, default=str)},
            *history[-6:],
            {"role": "user", "content": question},
        ]
        resp = client.chat.completions.create(model=get_model_name(), messages=messages)
        text = resp.choices[0].message.content
        return (text or "The model returned an empty answer."), None
    except Exception as exc:  # map common API failures to friendly text
        name = type(exc).__name__
        if "Authentication" in name or "PermissionDenied" in name:
            return None, "The API key was rejected. Check OPENAI_API_KEY in your Streamlit secrets."
        if "RateLimit" in name:
            return None, "The AI service rate limit or quota was reached. Try again shortly or check billing."
        if "Connection" in name or "Timeout" in name:
            return None, "Could not reach the AI service. Check the network connection and try again."
        if "NotFound" in name:
            return None, f"Model '{get_model_name()}' was not found. Set OPENAI_MODEL to a model your account can use."
        return None, f"The AI service returned an error ({name}). The dashboard is unaffected."


def render_chatbot(d: pd.DataFrame, cust: pd.DataFrame, meta: dict, filter_desc: str) -> None:
    st.subheader("Ask the data")
    st.caption("Answers are generated from the aggregates of the currently filtered data shown in this dashboard. "
               "Only summary tables and a short list of pseudonymous customer IDs are sent to the AI provider.")
    api_key = get_api_key()
    if not api_key:
        st.warning("The AI assistant is not configured, so it is switched off. All dashboard analytics still work.")
        st.markdown(
            "**Setup**\n"
            "1. Get an OpenAI API key from your OpenAI account.\n"
            "2. Locally: create `.streamlit/secrets.toml` containing `OPENAI_API_KEY = \"sk-...\"` "
            "(or set the `OPENAI_API_KEY` environment variable).\n"
            "3. On Streamlit Community Cloud: App -> Settings -> Secrets, paste the same line.\n"
            "4. Optional: `OPENAI_MODEL = \"gpt-4o-mini\"` to choose the model. Then rerun the app."
        )
        return

    st.session_state.setdefault("chat", [])
    st.info(f"Current context: {filter_desc}")
    for m in st.session_state["chat"]:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])
            if m.get("ctx"):
                st.caption(f"Filters at time of answer: {m['ctx']}")

    examples = ["Which segment generates the most revenue?", "Which categories have the highest revenue?",
                "How does online compare with physical stores?", "What warning signs appear among Decline customers?"]
    st.caption("Examples: " + " · ".join(examples))
    if st.button("Clear conversation"):
        st.session_state["chat"] = []
        st.rerun()

    q = st.chat_input("Ask a question about the filtered data")
    if q:
        history = [{"role": m["role"], "content": m["content"]} for m in st.session_state["chat"]]
        with st.spinner("Analysing..."):
            ans, err = ask_llm(q, history, build_chat_context(d, cust, meta, filter_desc), api_key)
        st.session_state["chat"].append({"role": "user", "content": q})
        st.session_state["chat"].append({"role": "assistant", "content": ans if ans else f"Sorry - {err}", "ctx": filter_desc})
        st.rerun()


# --------------------------------------------------------------------------
# Rendering helpers
# --------------------------------------------------------------------------
def style_fig(fig, height: int = 340):
    fig.update_layout(height=height, margin=dict(l=10, r=10, t=50, b=10), legend_title_text="",
                      font=dict(size=13))
    return fig


def bar(df, x, y, title, color=None, fmt="$,.0f", orientation="v", hover=None, cmap=None, text=None):
    fig = px.bar(df, x=x, y=y, color=color, orientation=orientation, title=title,
                 color_discrete_map=cmap, hover_data=hover, text=text if text else (x if orientation == "h" else y))
    fig.update_traces(texttemplate="%{text:" + fmt + "}", textposition="outside", cliponaxis=False)
    return style_fig(fig)


def seg_heatmap(d: pd.DataFrame, col: str, title: str):
    pv = d.pivot_table(index="Segment", columns=col, values="Amount", aggfunc="sum", fill_value=0.0)
    pv = pv.reindex([s for s in SEGMENT_ORDER if s in pv.index])
    fig = px.imshow(pv, text_auto="$,.0f", aspect="auto", color_continuous_scale="Blues", title=title,
                    labels=dict(color="Revenue", x=col, y="Segment"))
    return style_fig(fig, 320)


MONEY_COL = lambda label: st.column_config.NumberColumn(label, format="$%.2f")  # noqa: E731


# --------------------------------------------------------------------------
# Tabs
# --------------------------------------------------------------------------
def tab_overview(d, cust, meta, audit):
    k = compute_kpis(d)
    c = st.columns(5)
    c[0].metric("Total revenue", money(k["revenue"]), help="Sum of PurchaseAmount for the filtered records.")
    c[1].metric("Unique customers", f"{k['customers']:,}", help="Distinct CustomerID (not a row count).")
    c[2].metric("Transactions", f"{k['transactions']:,}",
                help=f"Purchase records. These share only {k['distinct_txids']} distinct TransactionIDs because IDs repeat across rows.")
    c[3].metric("Avg transaction value", money(k["avg_tx"], 2), help="Revenue / number of records.")
    c[4].metric("Avg satisfaction", "n/a" if np.isnan(k["avg_sat"]) else f"{k['avg_sat']:.2f} / 5",
                help=f"Mean of valid 1-5 ratings ({k['sat_n']} ratings).")

    st.markdown("#### At a glance (observed)")
    seg = segment_summary(d).sort_values("Revenue", ascending=False)
    cat = dim_summary(d, "Category")
    top5 = cust.nlargest(5, "Revenue")["Revenue"].sum() / k["revenue"]
    rec_rev, pri_rev = cust["RecentRevenue"].sum(), cust["PriorRevenue"].sum()
    if pri_rev > 0:
        trend_line = (f"- Revenue in the last {meta['window']} days was {money(rec_rev)} vs {money(pri_rev)} in the "
                      f"{meta['window']} days before ({(rec_rev - pri_rev) / pri_rev:+.0%}).\n")
    else:
        trend_line = "- Not enough prior-period data under these filters to compare recent revenue.\n"
    st.markdown(
        f"- **{seg.iloc[0]['Segment']}** is the largest segment by revenue: {money(seg.iloc[0]['Revenue'])} "
        f"({seg.iloc[0]['RevenueShare']:.0%}).\n"
        f"- **{cat.iloc[0]['Category']}** is the top category ({cat.iloc[0]['RevenueShare']:.0%} of revenue).\n"
        f"- The top 5 customers account for **{top5:.0%}** of revenue.\n"
        + trend_line +
        f"- {int((cust['RiskLevel'] == 'Elevated').sum())} of {len(cust)} customers show 2+ independent warning signs."
    )
    st.info(
        f"Data caveat: the file holds {audit['rows_clean']} purchase records for {audit['unique_customers']} unique customers "
        f"over {audit['span_days']} days ({audit['date_min']:%b %d} - {audit['date_max']:%b %d, %Y}). "
        "Findings are indicative, not statistically conclusive."
    )


def tab_segments(d, cust, meta):
    seg = segment_summary(d)
    st.markdown("#### Segment comparison")
    st.dataframe(seg, hide_index=True, column_config={
        "Revenue": MONEY_COL("Revenue"), "RevenueShare": st.column_config.NumberColumn("Revenue share", format="percent"),
        "Customers": st.column_config.NumberColumn("Customers*"),
        "TxPerCustomer": st.column_config.NumberColumn("Transactions / customer", format="%.2f"),
        "AvgTransaction": MONEY_COL("Avg transaction"),
        "AvgSatisfaction": st.column_config.NumberColumn("Avg satisfaction", format="%.2f"),
    })
    st.caption(f"*Segment labels sit on individual records, so a customer can appear in several segments; "
               f"segment customer counts sum to {int(seg['Customers'].sum())} vs {d['CustomerID'].nunique()} unique customers overall.")
    a, b = st.columns(2)
    seg_text = seg.assign(Share=seg["RevenueShare"])
    fig = px.bar(seg_text, x="Segment", y="Revenue", color="Segment", color_discrete_map=SEGMENT_COLORS,
                 title="Revenue and contribution to total", custom_data=["RevenueShare"], text="Revenue")
    fig.update_traces(texttemplate="%{text:$,.0f}<br>(%{customdata[0]:.0%})", textposition="outside", cliponaxis=False,
                      hovertemplate="%{x}<br>Revenue %{y:$,.0f}<br>Share %{customdata[0]:.1%}<extra></extra>")
    a.plotly_chart(style_fig(fig).update_layout(showlegend=False))
    b.plotly_chart(bar(seg, "Segment", "AvgTransaction", "Average transaction value", color="Segment",
                       cmap=SEGMENT_COLORS, fmt="$,.0f").update_layout(showlegend=False))
    a, b = st.columns(2)
    a.plotly_chart(bar(seg, "Segment", "Customers", "Customers appearing in segment", color="Segment",
                       cmap=SEGMENT_COLORS, fmt=",.0f").update_layout(showlegend=False))
    b.plotly_chart(bar(seg, "Segment", "TxPerCustomer", "Transactions per customer", color="Segment",
                       cmap=SEGMENT_COLORS, fmt=".1f").update_layout(showlegend=False))

    st.markdown("#### Highest-revenue customers vs. recent growth")
    n_max = min(20, len(cust))
    if n_max > 3:  # a slider needs min < max; with <=3 customers just show them all
        n = st.slider("Customers to show", 3, n_max, min(10, n_max))
    else:
        n = n_max
    top = cust.nlargest(n, "Revenue")
    a, b = st.columns(2)
    fig = px.bar(top.sort_values("Revenue"), x="Revenue", y="CustomerID", orientation="h", color="LatestSegment",
                 color_discrete_map=SEGMENT_COLORS, title=f"Top {n} customers by historical revenue",
                 hover_data={"Transactions": True, "AvgSatisfaction": ":.2f"}, text="Revenue")
    fig.update_traces(texttemplate="%{text:$,.0f}", textposition="outside", cliponaxis=False)
    fig.update_yaxes(type="category")
    a.plotly_chart(style_fig(fig, 400))
    growers = cust[cust["RecentGrowth"]].sort_values("RevenueChange", ascending=False).head(n)
    if growers.empty:
        b.info("No customers increased spend in the recent window versus the prior window.")
    else:
        fig = px.bar(growers.sort_values("RevenueChange"), x="RevenueChange", y="CustomerID", orientation="h",
                     color="LatestSegment", color_discrete_map=SEGMENT_COLORS,
                     title=f"Recent growth: change in spend ({meta['window']}d vs prior {meta['window']}d)",
                     text="RevenueChange", hover_data={"RecentRevenue": ":$,.0f", "PriorRevenue": ":$,.0f"})
        fig.update_traces(texttemplate="%{text:+$,.0f}", textposition="outside", cliponaxis=False)
        fig.update_yaxes(type="category")
        b.plotly_chart(style_fig(fig, 400))
    st.caption(f"Recent window: {meta['recent_range'][0]:%b %d}-{meta['recent_range'][1]:%b %d}; prior window: "
               f"{meta['prior_range'][0]:%b %d}-{meta['prior_range'][1]:%b %d}. Customers can be high historical revenue, "
               "recent growth, both or neither.")
    fig = px.scatter(cust, x="Revenue", y="RevenueChange", color="LatestSegment", size="Transactions",
                     color_discrete_map=SEGMENT_COLORS, hover_name="CustomerID",
                     title="Historical revenue vs recent change in spend",
                     labels={"Revenue": "Historical revenue ($)", "RevenueChange": "Recent minus prior spend ($)"})
    fig.add_hline(y=0, line_dash="dot", line_color="gray")
    st.plotly_chart(style_fig(fig, 380))
    st.dataframe(top[["CustomerID", "Revenue", "Transactions", "LatestSegment", "AvgSatisfaction", "RecentRevenue", "PriorRevenue"]],
                 hide_index=True, column_config={
                     "Revenue": MONEY_COL("Historical revenue"), "RecentRevenue": MONEY_COL("Recent"),
                     "PriorRevenue": MONEY_COL("Prior"), "LatestSegment": "Latest segment label",
                     "AvgSatisfaction": st.column_config.NumberColumn("Avg satisfaction", format="%.2f")})


def tab_trends(d):
    st.markdown("#### Revenue over time")
    a, b = st.columns(2)
    gran = a.radio("Granularity", ["Daily", "Weekly"], horizontal=True)
    split = b.selectbox("Split by", ["None", "Segment", "Channel", "Region"])
    freq = "D" if gran == "Daily" else "W-SUN"
    keys = [pd.Grouper(key="Date", freq=freq)] + ([] if split == "None" else [split])
    t = d.groupby(keys)["Amount"].sum().reset_index()
    if split == "None":
        fig = px.line(t, x="Date", y="Amount", markers=True, title=f"{gran} revenue")
    else:
        fig = px.line(t, x="Date", y="Amount", color=split, markers=True, title=f"{gran} revenue by {split.lower()}",
                      color_discrete_map=SEGMENT_COLORS if split == "Segment" else None)
    fig.update_yaxes(tickprefix="$", tickformat=",.0f", title="Revenue")
    st.plotly_chart(style_fig(fig, 380))
    if gran == "Weekly":
        st.caption("Weeks end on Sunday; the first and last weeks may be partial.")

    a, b = st.columns(2)
    cat = dim_summary(d, "Category")
    a.plotly_chart(bar(cat.sort_values("Revenue"), "Revenue", "Category", "Revenue by product category",
                       orientation="h", hover=["Transactions", "Customers"]).update_layout(height=380))
    reg = dim_summary(d, "Region")
    b.plotly_chart(bar(reg, "Region", "Revenue", "Revenue by region", hover=["Transactions", "Customers"]))
    a, b = st.columns(2)
    ch = dim_summary(d, "Channel")
    a.plotly_chart(bar(ch, "Channel", "Revenue", "Revenue by retail channel", hover=["Transactions", "Customers"]))
    b.plotly_chart(bar(ch, "Channel", "AvgTransaction", "Average transaction value by channel", fmt="$,.0f"))

    st.markdown("#### Segment contribution by category and region")
    a, b = st.columns(2)
    a.plotly_chart(seg_heatmap(d, "Category", "Revenue: segment x category"))
    b.plotly_chart(seg_heatmap(d, "Region", "Revenue: segment x region"))
    st.caption("Heatmap cells show revenue; darker = higher. Zero cells mean no filtered records.")


def tab_risk(d, cust, meta):
    st.warning("Warning signs below are indicators from limited data, not proof of future churn. "
               "The supplied segment label and the independently calculated indicators are shown separately.")
    dec_rec = d[d["Segment"] == "Decline"]
    dec_c = cust[cust["DeclineRecords"] > 0]
    c = st.columns(4)
    c[0].metric("Decline-labeled records", f"{len(dec_rec):,}")
    c[1].metric("Customers with a Decline record", f"{len(dec_c):,}")
    c[2].metric("Decline share of revenue", f"{(dec_rec['Amount'].sum() / d['Amount'].sum()):.0%}")
    sd, so = dec_rec["Satisfaction"].mean(), d[d["Segment"] != "Decline"]["Satisfaction"].mean()
    c[3].metric("Avg satisfaction: Decline vs others",
                "n/a" if np.isnan(sd) else f"{sd:.2f} vs {'n/a' if np.isnan(so) else f'{so:.2f}'}")

    st.markdown("#### Independent risk indicators (customer level)")
    st.markdown(
        f"- **Inactive**: no purchase in the last {meta['window']} days of the filtered data\n"
        f"- **Spend drop**: still active, but recent spend < {SPEND_DROP_RATIO:.0%} of prior-period spend\n"
        f"- **Low satisfaction**: average rating <= {LOW_SAT_THRESHOLD}\n"
        "- Risk level: 0 flags = Low, 1 = Watch, 2+ = Elevated"
    )
    if meta["window_adjusted"]:
        st.caption(f"The recent window was shortened to {meta['window']} days because the filtered period is short.")
    only_dec = st.checkbox("Show only customers with at least one Decline record", value=True)
    view = cust[cust["DeclineRecords"] > 0] if only_dec else cust
    view = view.sort_values(["RiskFlags", "Revenue"], ascending=False)
    if view.empty:
        st.info("No customers match this view under the current filters.")
    else:
        st.dataframe(view[["CustomerID", "LatestSegment", "DeclineRecords", "Revenue", "Transactions", "DaysSinceLast",
                           "RecentRevenue", "PriorRevenue", "AvgSatisfaction", "Inactive", "SpendDrop",
                           "LowSatisfaction", "RiskLevel"]], hide_index=True,
                     column_config={"Revenue": MONEY_COL("Revenue"), "RecentRevenue": MONEY_COL("Recent"),
                                    "PriorRevenue": MONEY_COL("Prior"), "DaysSinceLast": "Days since last purchase",
                                    "LatestSegment": "Latest segment label", "DeclineRecords": "Decline records",
                                    "AvgSatisfaction": st.column_config.NumberColumn("Avg satisfaction", format="%.2f")})
        st.caption("Customers with a single purchase record have no trend history, so 'Inactive' only means they have not purchased again.")

    st.markdown("#### Label vs independent indicators")
    xt = pd.crosstab(cust["LatestSegment"], cust["RiskLevel"]).reindex(
        index=[s for s in SEGMENT_ORDER if s in set(cust["LatestSegment"])],
        columns=[c_ for c_ in ["Low", "Watch", "Elevated"]], fill_value=0)
    st.dataframe(xt)
    st.caption("Customers by their most recent segment label (rows) and independently calculated risk level (columns).")

    a, b = st.columns(2)
    seg = segment_summary(d)
    fig = px.bar(seg.dropna(subset=["AvgSatisfaction"]), x="Segment", y="AvgSatisfaction", color="Segment",
                 color_discrete_map=SEGMENT_COLORS, title="Average satisfaction by segment", text="AvgSatisfaction",
                 hover_data={"Transactions": True})
    fig.update_traces(texttemplate="%{text:.2f}", textposition="outside", cliponaxis=False)
    fig.update_yaxes(range=[0, 5.5], title="Rating (1-5)")
    a.plotly_chart(style_fig(fig).update_layout(showlegend=False))
    rp = segment_recent_vs_prior(d, meta).melt("Segment", var_name="Period", value_name="Revenue")
    fig = px.bar(rp, x="Segment", y="Revenue", color="Period", barmode="group", title="Segment revenue: prior vs recent window",
                 color_discrete_map={"Prior": "#B0B7C3", "Recent": "#4C78A8"}, text="Revenue")
    fig.update_traces(texttemplate="%{text:$,.0f}", textposition="outside", cliponaxis=False)
    b.plotly_chart(style_fig(fig))

    st.markdown("#### Satisfaction and spending")
    rho_c, n_c = safe_corr(cust["AvgSatisfaction"], cust["Revenue"])
    rho_r, n_r = safe_corr(d["Satisfaction"], d["Amount"])
    fig = px.scatter(cust, x="AvgSatisfaction", y="Revenue", color="LatestSegment", color_discrete_map=SEGMENT_COLORS,
                     hover_name="CustomerID", size="Transactions", title="Customer satisfaction vs historical revenue",
                     labels={"AvgSatisfaction": "Average satisfaction (1-5)", "Revenue": "Revenue ($)"})
    st.plotly_chart(style_fig(fig, 360))
    f = lambda v: "n/a" if np.isnan(v) else f"{v:+.2f}"  # noqa: E731
    st.caption(f"Spearman rank correlation: customer-level {f(rho_c)} (n={n_c}); record-level {f(rho_r)} (n={n_r}). "
               "This is an association in a small sample, not evidence that satisfaction causes spending.")


def tab_recs(d, cust, meta):
    st.markdown("Each recommendation separates **observed** results (computed from the filtered data), "
                "**hypotheses** (not tested) and the **proposed action**.")
    recs = build_recommendations(d, cust, meta)
    if not recs:
        st.info("Not enough data under the current filters to generate recommendations.")
    for i, r in enumerate(recs, 1):
        with st.expander(f"{i}. {r['title']}", expanded=i <= 2):
            st.markdown(f"**Observed:** {r['observed']}")
            st.markdown(f"**Hypothesis:** {r['hypothesis']}")
            st.markdown(f"**Target:** {r['target']}")
            st.markdown(f"**Recommended action:** {r['action']}")
            st.markdown(f"**Success metric:** {r['metric']}")


def tab_quality(df, audit, sheets):
    st.markdown("#### Dataset audit")
    c = st.columns(4)
    c[0].metric("Rows", audit["rows_raw"])
    c[1].metric("Unique customers", audit["unique_customers"])
    c[2].metric("Unique TransactionIDs", audit["unique_transaction_ids"])
    c[3].metric("Period (days)", audit["span_days"])
    st.write(f"Worksheet(s): {', '.join(sheets)} | Columns: {len(audit['columns'])}")
    miss = {k_: v for k_, v in audit["missing_by_column"].items() if v}
    st.write("Missing values: " + (", ".join(f"{k_}: {v}" for k_, v in miss.items()) or "none"))
    st.markdown("**Cleaning decisions and flags**")
    for x in audit["decisions"]:
        st.markdown(f"- {x}")
    st.markdown("**Records flagged (retained)**")
    fl = df[df["PossibleDuplicate"] | df["SharedTransactionID"]]
    st.dataframe(fl[["RecordID", "CustomerID", "TransactionID", "Date", "RawCategory", "Amount", "Segment",
                     "PossibleDuplicate", "SharedTransactionID"]], hide_index=True,
                 column_config={"Amount": MONEY_COL("Amount")})
    st.markdown("**Category standardisation**")
    st.dataframe(df.groupby(["Category", "RawCategory"]).size().rename("Records").reset_index(), hide_index=True)


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------
def main() -> None:
    st.title("NovaRetail Customer Intelligence")
    st.caption("Revenue, segment performance, customer risk and investment priorities.")

    try:
        raw, sheets = load_raw(str(DATA_PATH), DATA_PATH.stat().st_mtime)
        df, audit = clean_data(raw)
    except FileNotFoundError:
        st.error("NR_dataset.xlsx was not found next to app.py. Add the dataset to the repository root and reload.")
        st.stop()
    except ValueError as e:
        st.error(f"Data problem: {e}")
        st.stop()
    except Exception as e:  # unexpected read/parse failure
        st.error(f"Could not load the dataset ({type(e).__name__}). Check that the file is a valid .xlsx.")
        st.stop()
    if df.empty:
        st.error("The dataset contains no valid records after validation.")
        st.stop()

    sel, window = sidebar_filters(df)
    dff = apply_filters(df, sel)
    if dff.empty:
        st.warning("No records match the current filters. Adjust the filters or click 'Reset filters' in the sidebar.")
        st.stop()

    cust, meta = customer_summary(dff, window)
    desc = describe_filters(df, dff, sel, meta["window"])
    st.caption(f"Filters applied: {desc}")

    tabs = st.tabs(["Executive Overview", "Customer Segmentation", "Revenue & Trends", "Risk & Retention",
                    "Recommendations", "AI Assistant", "Data Quality"])
    with tabs[0]:
        tab_overview(dff, cust, meta, audit)
    with tabs[1]:
        tab_segments(dff, cust, meta)
    with tabs[2]:
        tab_trends(dff)
    with tabs[3]:
        tab_risk(dff, cust, meta)
    with tabs[4]:
        tab_recs(dff, cust, meta)
    with tabs[5]:
        render_chatbot(dff, cust, meta, desc)
    with tabs[6]:
        tab_quality(df, audit, sheets)


if __name__ == "__main__":
    main()
