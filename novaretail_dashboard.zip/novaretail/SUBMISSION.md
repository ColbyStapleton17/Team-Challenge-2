# NovaRetail Dashboard: Audit, Definitions, Testing and Submission

All figures below were computed from `NR_dataset.xlsx` with the code in `app.py`.

## 1. Dataset audit and selected variables

| Check | Result |
|---|---|
| Worksheet | `data` (1 sheet), 100 rows x 12 columns |
| Brief says | "99 customers"; the file has **100 rows and 34 unique CustomerIDs** |
| Missing values | 1 (blank `label`, row for customer 12509); none elsewhere |
| TransactionID uniqueness | **Not unique**: 25 distinct IDs; 85 rows share an ID; 9 IDs are shared by more than one CustomerID (e.g. TX1006 appears for 12350 and 23456) |
| CustomerID | 34 distinct (12345-12359, 12500-12509, 23456-23464); 24 customers have a single record |
| Dates | All valid, 2023-01-15 to 2023-02-20 (37 days); 72 records in Jan, 28 in Feb |
| Amounts | All positive, $12.99 to $999.99, total $16,969 |
| Satisfaction | All within 1-5 |
| Categories | 35 raw spellings (e.g. Grocery / Groceries / Grocery Items) |
| Age group | `55+` (2 rows) and `55-64` (1 row) |
| Segment labels | Promising 31, Growth 29, Stable 20, Decline 19, blank 1 |
| Label consistency | Labels are per record: 10 customers carry more than one label; 10 customers appear in more than one region and 10 in more than one age group |
| Possible duplicates | 4 rows share customer+date+amount+category (e.g. records 46 and 52: 12354, 24 Jan, $99.99, Fashion & Apparel); flagged, retained |

**Cleaning decisions**: kept every row; blank label -> `Unlabeled`; categories consolidated to 9 groups (Electronics, Clothing & Fashion, Groceries & Food, Books, Home & Furniture, Health & Beauty, Sports & Outdoors, Toys & Games, Other); `55-64` -> `55+`; Gaming grouped with Electronics and Office Supplies/Automotive with Other (analyst judgement, editable in `CATEGORY_MAP`); duplicates and shared IDs flagged only.

**Selected variables**: CustomerID, TransactionID (reference only), TransactionDate, ProductCategory, PurchaseAmount, label (segment), CustomerRegion, RetailChannel, CustomerSatisfaction, CustomerAgeGroup and CustomerGender (filters). `idx` is used only as a tie-breaker for record order.

## 2. Dashboard layout and visualization plan

| Tab | Visuals | Question served |
|---|---|---|
| Executive Overview | 5 KPI cards, computed "at a glance" bullets, data caveat | 1, 2 |
| Customer Segmentation | Segment table; bars for revenue (with share %), customers, transactions per customer, average transaction; top-N customers bar; recent-growth bar; historical revenue vs recent change scatter | 1, 2 |
| Revenue & Trends | Daily/weekly line (optionally split by segment/channel/region); category, region, channel bars; average ticket by channel; segment x category and segment x region heatmaps | 1, 3 |
| Risk & Retention | Decline KPIs; risk-indicator table; label vs risk crosstab; satisfaction by segment; prior vs recent revenue by segment; satisfaction vs revenue scatter with correlation | 2 |
| Recommendations | Five computed recommendations (observed / hypothesis / target / action / metric) | 3 |
| AI Assistant | Chat grounded in filtered data | all |
| Data Quality | Audit, flags, category mapping | trust |

Sidebar: date range, segment, category, region, channel, age group, gender, recent-window slider (7-21 days), reset button.

## 3. Analytical definitions

- **Revenue** = sum of PurchaseAmount. **Transactions** = number of purchase records (rows). **Unique customers** = `nunique(CustomerID)`. **Average transaction value** = revenue / records. **Average satisfaction** = mean of valid 1-5 ratings.
- **Revenue share** = segment revenue / total revenue. **Transactions per customer** = records / distinct customers in that group.
- **Segment customer counts overlap** (a customer can hold several labels), so they sum to more than 34.
- **Customer latest segment** = label on the customer's most recent record.
- **Recent window** = last N days of the filtered data (default 14); **prior window** = the N days before it. **Recent growth** = recent spend > prior spend and > 0. Window shrinks automatically for short date ranges.
- **Independent risk indicators** (not using the label): *Inactive* = no purchase in the recent window; *Spend drop* = active but recent spend < 50% of prior spend; *Low satisfaction* = average rating <= 2.5. Flags 0 = Low, 1 = Watch, 2+ = Elevated.
- **Correlation** = Spearman rank correlation, reported with n and treated as association only.

## 4-7. Files

`app.py`, `requirements.txt`, `README.md`, `FINAL_PROMPT.md` and `NR_dataset.xlsx` are delivered as files with complete contents.

## 8. Testing checklist and limitations

Tests marked **Run** were executed during development (Streamlit 1.66 AppTest harness, pandas 3.0.5, Python 3.13). Items marked **Not run** need you.

| # | Check | Status |
|---|---|---|
| 1 | Dataset loads from relative path; expected columns validated | Run, pass |
| 2 | KPIs reconcile to raw file (revenue $16,969.00, 100 records, 34 customers); segment revenues match raw group sums; shares sum to 100% | Run, pass |
| 3 | Transactions never reused as customer count | Run, pass (100 vs 34) |
| 4 | Default load, single-segment (all 5), region+channel combo, narrow date range, one-day range, half-selected date range: no exceptions | Run, pass |
| 5 | Empty selection shows warning, no crash | Run, pass |
| 6 | Reset filters restores defaults | Run, pass |
| 7 | Chart/table slider crash with <=3 customers | Run, **bug found and fixed**, re-tested |
| 8 | Chatbot: no key shows setup instructions; mocked success, auth error, rate limit, connection and generic errors handled | Run, pass (mocked client) |
| 9 | Chatbot context reflects filters (West filter -> $5,032.77 matches raw) | Run, pass |
| 10 | No hard-coded API key in source; key read from secrets/env; `secrets.toml` git-ignored | Run (source scan), pass |
| 11 | Streamlit server starts and health endpoint returns OK | Run, pass |
| 12 | Clean-environment install from `requirements.txt` | **Not run** (tested in an environment where packages were installed directly; lower version bounds untested) |
| 13 | Live OpenAI call with a real key | **Not run** |
| 14 | Visual inspection of charts in a browser | **Not run** (charts were checked via data reconciliation, not by eye) |
| 15 | GitHub + Streamlit Community Cloud deployment and public URL | **Not run**, requires your accounts |

**Limitations**: 37-day window and 34 customers; 24 customers with one record; labels/attributes inconsistent across a customer's rows; no margin, cost, returns or marketing spend; overall recent-vs-prior revenue decline may partly reflect how the dataset was assembled rather than real behaviour.

## 9. Deploy and verify

See `README.md` (steps 1-7). Verification: with default filters expect $16,969 revenue, 34 unique customers, 100 transactions, $169.69 average transaction, 3.71 average satisfaction. Selecting only Region = West should show $5,033 revenue and 15 customers.

## 10. Three business insights and submission note

### Insight 1: Revenue is concentrated in a few repeat customers (growth/concentration)
- **Evidence**: The top 5 of 34 customers (12351, 12358, 12354, 12356, 12353) generate $8,251, i.e. **49%** of $16,969. They also account for **63%** of Electronics revenue ($4,559.91 of $7,289.83). Their combined spend was $2,100 in the last 14 days vs $3,686 in the prior 14 (-43%).
- **Interpretation (hypothesis)**: Revenue depends on a small group of heavy buyers, so a lapse by one or two would be material. The data cannot explain why they spend more.
- **Action**: Assign relationship owners, loyalty/early-access offers and weekly activity monitoring for the top customers. Success metric: top-5 revenue retention and repeat-purchase rate next quarter.

### Insight 2: Decline-labeled records show very low satisfaction and no return purchases (retention risk)
- **Evidence**: Decline records are 19 of 100 and $3,650 (**22%**) of revenue, with average satisfaction **1.58 vs 4.21** on all other records. Ten customers whose latest label is Decline each have a single purchase (last bought 18-30 Jan, average satisfaction 1.3, $1,210 total) and all ten are Elevated on the independent indicators. 11 of 19 Decline records, **72%** of Decline revenue, are Physical Store.
- **Interpretation**: Low satisfaction accompanies the Decline label and these customers have not returned within the data window. This is an association; it does not prove churn, and "not returned" is partly mechanical for one-time buyers. The other 9 Decline records belong to high-activity customers whose latest label is Growth, which shows labels are not stable per customer.
- **Action**: Service-recovery outreach and a satisfaction follow-up for the ten customers, starting with Physical Store experiences. Success metric: 30-day repurchase rate and change in satisfaction. Additional data needed: longer history, reason codes for low ratings, label definitions.

### Insight 3: Electronics, Physical Stores and West/North are the investment core (strategic decision)
- **Evidence**: Electronics earns $7,290 (**43%** of revenue) from only 17 of 100 records (average $429 vs $170 overall). Physical Store generates 56% of revenue and a higher average ticket ($190 vs $149 online); Physical Store Electronics averages $484 vs $350 online. West and North together are 59% of revenue; Books is 2.5%.
- **Interpretation (hypothesis)**: Big-ticket Electronics in physical stores drives revenue, while Books/Groceries add volume but little revenue. Margin is unknown, so profitability is not established.
- **Action**: Prioritise Electronics stock and promotion in Physical Stores in West/North, and pilot Electronics bundles online to close the ticket gap. Success metric: Electronics revenue per store/region, online average ticket. Additional data needed: margin, inventory and marketing cost.

### Brightspace submission note (template)

> **Public Streamlit dashboard URL**: `[paste URL here after you deploy and verify it]`
> **Submitted files**: app.py, requirements.txt, NR_dataset.xlsx, README.md, FINAL_PROMPT.md
> **Insights**: (1) Top 5 of 34 customers generate 49% of revenue and 63% of Electronics revenue. (2) Decline-labeled records average 1.58 satisfaction vs 4.21 elsewhere; ten Decline customers bought once and have not returned. (3) Electronics is 43% of revenue, Physical Store is 56%, and West+North are 59%; margin data is needed before shifting budget.
> **Team contribution**: `[Fill in from your team's actual records: either "All team members contributed equally" or list only the names of members who actively contributed.]`
