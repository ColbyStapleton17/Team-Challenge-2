# FINAL PROMPT

This is the consolidated prompt that specifies the delivered application. It reflects the original project brief plus the data realities discovered during the audit.

---

Act as a senior Business Intelligence Analyst, Customer Analytics Specialist, Python developer and Streamlit designer for NovaRetail, a nationwide omnichannel retailer. The audience is Sophia Martinez, Director of Customer Intelligence, and business leadership.

**Data**: `NR_dataset.xlsx` (worksheet `data`, columns: idx, label, CustomerID, TransactionID, TransactionDate, ProductCategory, PurchaseAmount, CustomerAgeGroup, CustomerGender, CustomerRegion, CustomerSatisfaction, RetailChannel). Segment labels (Promising, Growth, Stable, Decline) are existing classifications; do not assume they came from a model or imply causation. Never fabricate values.

**Business questions**: (1) which customers and segments generate the most revenue; (2) which show warning signs of declining engagement; (3) where to prioritise commercial and marketing investment.

**Data preparation rules**: load with pandas/openpyxl; audit sheets, columns, types, missing values, duplicates; validate TransactionID, CustomerID, dates, amounts, categories and labels; flag (never silently delete) possible duplicates; document every cleaning decision; aggregate to customer level with CustomerID; never confuse transaction counts with unique customers. The audit found that TransactionID is not unique, customers carry multiple labels/regions/age groups across rows, category names have many spellings, one label is blank and the window is about five weeks, so the app must handle and disclose these.

**Dashboard** (Streamlit + Plotly): Executive Overview (revenue, unique customers, transactions, average transaction value, average satisfaction); Customer Segmentation (revenue, customers, frequency, average spend, revenue share, top customers, high-historical vs recent-growth customers); Revenue & Trends (time series, category/region/channel comparisons, segment x category and segment x region heatmaps); Risk & Retention (Decline customers, recent activity, spend change, satisfaction vs segment and spend, independent risk indicators kept separate from the segment label, no churn claims); Recommendations (evidence, target, action, success metric; observed vs hypothesis); Data Quality tab.

**Interactivity**: sidebar filters for date range, segment, category, region, channel, age group, gender that work together and drive every KPI, chart, table and chatbot context; reset button; sensible defaults; currency formatting; tooltips; graceful empty states.

**Chatbot**: OpenAI API via official client; key from Streamlit secrets or environment, never hard-coded; answers grounded in pre-computed aggregates of the filtered data; states filter context; separates observed / hypothesis / recommendation; says when evidence is insufficient; limits personal data; handles missing key and API errors gracefully while the analytics remain usable.

**Engineering**: modular functions for loading, cleaning, metrics, filters, charts, chatbot; `st.cache_data`; exception handling; comments on analytical calculations; minimal dependencies.

**Deliverables**: `app.py`, `requirements.txt`, `NR_dataset.xlsx`, `README.md` (setup, secrets, GitHub + Streamlit Community Cloud deployment), `FINAL_PROMPT.md`, plus testing checklist, limitations, three evidence-based insights and a submission note. Do not claim tests were run unless they were, and do not invent a deployment URL or team-contribution facts.
