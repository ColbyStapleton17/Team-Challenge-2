# NovaRetail Customer Intelligence Dashboard

Interactive Streamlit dashboard built on `NR_dataset.xlsx` for Sophia Martinez (Director of Customer Intelligence). It answers three questions: who generates revenue, where are the warning signs, and where to invest.

## Repository contents

| File | Purpose |
|---|---|
| `app.py` | Complete Streamlit application (loading, cleaning, metrics, filters, charts, chatbot) |
| `requirements.txt` | Python dependencies |
| `NR_dataset.xlsx` | Dataset (must sit next to `app.py`; read via a relative path) |
| `README.md` | This file |
| `FINAL_PROMPT.md` | Final prompt used to generate the application |
| `SUBMISSION.md` | Data audit, metric definitions, testing checklist, insights, submission note |
| `.streamlit/secrets.toml.example` | Template for API-key configuration |
| `.gitignore` | Keeps `secrets.toml` out of GitHub |

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

Open the URL Streamlit prints (usually http://localhost:8501). The app was developed and tested with Python 3.13, Streamlit 1.66, pandas 3.0, Plotly 7.1 and openai 3.31.

## Configure the AI chatbot (optional)

The dashboard works fully without a key; the **AI Assistant** tab then shows setup instructions.

1. Create an OpenAI API key.
2. Locally: `cp .streamlit/secrets.toml.example .streamlit/secrets.toml` and edit the key (or `export OPENAI_API_KEY=...`).
3. Optional: set `OPENAI_MODEL` (default `gpt-4o-mini`).

**Never commit `secrets.toml` or paste a key into code.** `.gitignore` already excludes it.

What is sent to the provider: pre-computed summary tables for the current filters plus up to ~20 pseudonymous CustomerIDs. Raw rows are not sent.

## Deploy to Streamlit Community Cloud

1. **Create the GitHub repository**: github.com -> New repository (public or private), e.g. `novaretail-dashboard`.
2. **Upload the files**: add `app.py`, `requirements.txt`, `NR_dataset.xlsx`, `README.md`, `FINAL_PROMPT.md`, `SUBMISSION.md`, `.gitignore` and `.streamlit/secrets.toml.example` (GitHub -> Add file -> Upload files; keep `app.py` in the repository root). Do **not** upload `secrets.toml`.
3. **Connect to Streamlit**: go to share.streamlit.io, sign in with GitHub, click **Create app** -> *Deploy a public app from GitHub*.
4. **Select the entry point**: choose the repository, branch `main`, main file path `app.py`.
5. **Configure secrets**: *Advanced settings -> Secrets*, paste:
   ```toml
   OPENAI_API_KEY = "sk-..."
   ```
   (Skip this to deploy without the chatbot.)
6. **Deploy**: click Deploy and wait for the build.
7. **Test the public dashboard**: open the URL and confirm the KPIs show `$16,969`, `34` unique customers and `100` transactions with default filters; change a filter and check the numbers update; reset filters; select an empty combination and confirm the warning appears; ask the chatbot a question if configured.

Steps 1-7 need your GitHub/Streamlit accounts, so they must be done by you. No URL is claimed here until you have deployed and verified it.

## Key analytical decisions (details in `SUBMISSION.md`)

- Each row is a purchase record; **TransactionID repeats** (25 distinct IDs over 100 rows), so transactions = record count and customers = distinct `CustomerID` (34).
- Segment labels are used **as supplied, per record**. Customers can carry several labels, so per-segment customer counts overlap.
- 35 category spellings are consolidated into 9 groups; `55-64` is merged into `55+`; one blank label becomes `Unlabeled`.
- Possible duplicates and shared TransactionIDs are **flagged, never deleted** (Data Quality tab).
- Risk indicators (inactive, spend drop, low satisfaction) are computed independently of the segment label.

## Known limitations

- Only 37 days of data (15 Jan - 20 Feb 2023) and 34 customers: trends are indicative, not statistically conclusive.
- 24 of 34 customers have a single record, so recency/trend indicators for them reflect "has not bought again", not a trend.
- Customer attributes (region, age group, segment) change between rows of the same customer; filters act on record values.
- No margin, cost, returns or marketing-spend data, so profitability and ROI cannot be assessed.
- The chatbot depends on an external API and on the quality of the supplied context; it has not been run against a live API key during development (only with a mocked client).
